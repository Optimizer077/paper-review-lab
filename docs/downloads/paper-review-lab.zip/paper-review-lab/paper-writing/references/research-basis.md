# Research basis: historical top-venue papers

The resource library is **10,000 citation records from 2022 or earlier**. Its [metadata registry](../../research/library-10000/papers.jsonl) and [summary](../../research/library-10000/summary.json) document fixed venue quotas, balanced publication years, unique identities and source provenance. All 300 original citation IDs are retained. The expanded metadata collection adds no new selected-section or scientific reviews.

The original **300-paper inspection collection** remains the basis of the existing writing-example notes. The [registry](../../research/historical-2022/papers.jsonl) records sources and inspection flags; the [summary](../../research/historical-2022/summary.json) records validated counts, downloads and corpus hash.

## Eligibility

Selected venues: CVPR, ICCV, NeurIPS, ICLR, ICML, NEJM, The Lancet, JAMA, BMJ, Nature Medicine and Nature. Conference records come from official main-conference listings. Medical records require exact print/electronic ISSN, publication year <=2022 and first-publication date <=2022-12-31. Later papers and workshops are excluded.

Fixed quotas and deterministic ordering within accessible strata form a convenience sample, not a systematic or representative review. Venue inclusion is a task-specific decision, not proof that every included paper is exemplary.

## Evidence levels

- **Collection:** actual source metadata and abstract obtained; not comprehension or validation.
- **Download:** a local PDF/XML body exists and matches its SHA-256; unavailable bodies remain marked.
- **Extraction:** text recovered from a body; not visual inspection or reading.
- **Selected-section inspection:** an agent read identified passages and recorded source-specific observations. The CV, ML and medical inspection ledgers identify papers and sections.
- **Scientific review:** requires relevant domain evidence, analyses/proofs, displays and assumptions; collection counts do not establish it.

The [historical lessons](historical-paper-lessons.md) synthesize specialist observations without claiming a fresh read of all 300 papers. The [source registry](sources.json) separates historical papers/older editorial guidance from current compliance sources. Current submission policies or reporting standards may postdate 2022 because they are outside the historical paper sample.

## Transfer to writing

Study how authors connect a problem, method, comparator and evidence; explain unfamiliar constructs; and preserve conditions around headline findings. Published examples can also expose ambiguous wording. Prefer supported reasoning to copying style.

Blind teach-back, ten reviewer roles, the context schema and scoring weights are toolkit design choices, not validated acceptance predictors or venue mandates. Consult [clarity](clarity-and-consistency.md), [section craft](section-craft.md), [evidence review](evidence-review.md), and [the scorecard](evaluation-scorecard.md).

Historical formatting does not determine present compliance. Recheck actual venue/year/track/stage through [venue profiles](venue-profiles.md), without adding newer papers to this historical example collection.

## Writing support beyond the historical papers

The [support catalog](writing-resources.md) separately tracks 42 selected primary-source writing guides, manuals, courses, reporting standards and tools, checked 2026-10-30. Its source-level inspection flags distinguish page content, book metadata and limited indexed excerpts. This adds workflow support rather than additional semantic paper reviews. Current support instructions may postdate 2022 without changing the 10,000-paper index cutoff.

## Public distribution

This export includes citation metadata and original editorial inspection notes only. Abstracts and article bodies are omitted. Original collection and inspection flags describe provenance; they do not imply that those source texts are bundled here. The summary distinguishes original collection counts from zero public local abstracts and article bodies. Follow source links to inspect originals.
