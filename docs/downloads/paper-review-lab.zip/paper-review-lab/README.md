# Paper writing toolkit

A portable scientific writing skill, mechanical manuscript audit, independent reviewer packet workflow, and evidence-backed editorial scoring tools. The audit and scorer use Python's standard library; they do not call an AI service.

Start with [the skill](paper-writing/SKILL.md), [harness commands](paper-writing/references/harness-guide.md), and [the scorecard](paper-writing/references/evaluation-scorecard.md). Run commands below from this toolkit directory.

```sh
python paper-writing/scripts/paper_harness.py --help
python paper-writing/scripts/paper_harness.py audit examples/manuscript.md --context examples/project.json --out audit.json
python paper-writing/scripts/paper_harness.py plan examples/manuscript.md --context examples/project.json --out review-plan.json
python paper-writing/scripts/score_evaluation.py --help
python -m unittest discover -s validation -p 'test*.py' -v
```

The examples contain explicitly invented data for software validation. Generated review packets are tasks, not completed reviews. Audit passes, declared evidence, and editorial scores do not verify scientific truth or predict acceptance.

## Iterative multi-agent revision

Use [the iterative workflow](paper-writing/references/iterative-review.md) for bounded review/revise/verify rounds, independent reviewers, a fresh-context blind reader and verified issue closure. The configurable defaults allow at most three rounds and stop after two consecutive rounds without substantive progress. Keep a single manuscript editor and immutable round records; the [state template](paper-writing/assets/iteration-state-template.json) supports resumption. The agent runtime dispatches reviewers; Python creates and checks packets.

```sh
python paper-writing/scripts/paper_harness.py plan examples/manuscript.md --context examples/project.json --select-roles argument,evidence,readability --out review/round-01/plan.json
```

Select a subset of the ten bundled roles or supply a nonempty custom role catalog. Merge requires every selected role and matching manuscript/context hashes. Subsequent rounds use fresh packets for affected roles, preserve unresolved evidence and stop with the actual reason. Scoring is opt-in; score increases do not close findings.

The manuscript rubric defines 24 anchored criteria across five domains, with empirical ML, theory, clinical, and systematic-review contribution profiles. Choose the relevant profile, supply inspected evidence and rationale, and report coverage and blockers alongside scores.

The scorer also includes an explicit aggressive scoring policy in `paper-writing/assets/scoring-policies.json`; consult `score_evaluation.py --help` and the scorecard for selection and interpretation. The aggressive policy changes scoring expectations, not the scientific evidence available.

## Writing support

The [task-by-task support guide](paper-writing/references/writing-support-guide.md) and [annotated catalog](paper-writing/references/writing-resources.md) cover selected university guides, manuals, courses, reporting standards and tools. The structured JSON catalog records checked sources, access and inspection limits. Support guidance is maintained separately from the historical paper index and may be newer.

## Historical citations and access

The expanded resource library in `research/library-10000/papers.jsonl` contains **10,000 unique citation records**, all published by 2022, including every original 300-paper citation ID. It covers 9,000 main-conference papers and 1,000 journal papers. It contains metadata only, with no new semantic-reading claims. Reproduce it with `python paper-writing/scripts/collect_library.py --output-root research/library-10000 --seed research/historical-2022/papers.jsonl --collect`; omit `--collect` to merge cached shards, or use `--validate` to check the shipped registry. Optional collector dependencies are listed in the corpus requirements file.

`research/historical-2022/papers.jsonl` contains 300 stable citation IDs with authors, venues, source links and bounded inspection provenance. This is a metadata-only export: zero local abstracts and zero article bodies. The original collection recorded 300 abstracts and 238 available bodies; those original counts are explicitly distinguished in `summary.json`. The accompanying specialist notes are original editorial observations, not complete article reviews. No journal full articles are mirrored. Use original publisher or repository links to inspect sources under their applicable access terms.

Collectors remain available as source code. They require the optional packages in `paper-writing/scripts/corpus-requirements.txt` and perform network access only when explicitly run. Collection metadata, downloads and selected-section inspection are separate evidence levels.

## Reproducing the public export

```sh
python publish_toolkit.py --source PATH_TO_OUTPUT_ROOT --dest PATH_TO_NEW_PUBLIC_TOOLKIT
```

The exporter uses a narrow allowlist, removes source abstracts and local body paths, converts known host-specific Markdown paths, rejects unrecognized home paths and common credentials, and emits a deterministic SHA-256 `public-manifest.json`. It excludes private drafts, research sessions, assessments, raw logs, archives and downloaded bodies. Re-running may replace only a destination previously marked by this exporter.
